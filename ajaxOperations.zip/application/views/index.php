<!DOCTYPE html>
<html>
<head>
	<title>Ajax Crud Operations</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
</head>
<body>
	<div class="container">
		<center>
			<h2>Crud Operations</h2>
		</center>
		<hr style="height: 8px; background: #000">
		<!-- Button trigger modal -->
		<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addModal">
		 Add Users
		</button>

		<hr style="height: 8px; background: #000">

		<table class="table table-striped">
			<thead>
				<tr>
					<th>ID</th>
					<th>USERNAME</th>
					<th>PASSWORD</th>
				</tr>
			</thead>
			<tbody id="tbody">


			</tbody>
		</table>






			<!-- Modal -->
		<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		  <div class="modal-dialog" role="document">
		    <div class="modal-content">
		      <div class="modal-header">
		        <h5 class="modal-title" id="exampleModalLabel">Add users</h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		        </button>
		      </div>

		      <form action="" method="post" id="form">
		      <div class="modal-body">

		       <div class="form-group">
		       	<label>Enter Username</label>
		       	<input type="text" name="" id="username" placeholder="Enter Username" class="form-control">
		       </div>

		       <div class="form-group">
		       	<label>Enter Password</label>
		       	<input type="text" name="" id="password" placeholder="Enter Password" class="form-control">
		       </div>


		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
		        <button type="button" class="btn btn-primary" id="add">Add</button>
		      </div>
		  	</form>


		    </div>
		  </div>
		</div>




<script src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>


<script type="text/javascript">
	$(document).on("click","#add",function(e){
		e.preventDefault();
		var username = $("#username").val();
		var password = $("#password").val();
		
		$.ajax({
			url: "<?php echo base_url()?>AjaxController/addUsers",
			type: "post",
			dataType: "json",
			data: {
				username:username,
				password:password
			},
			success:function(response){
				if(response["status"] == "success"){
					$("#addModal").modal("hide");
					toastr["success"](response["message"])
					toastr.options = {
					  "closeButton": true,
					  "debug": false,
					  "newestOnTop": false,
					  "progressBar": true,
					  "positionClass": "toast-top-right",
					  "preventDuplicates": false,
					  "onclick": null,
					  "showDuration": "300",
					  "hideDuration": "1000",
					  "timeOut": "5000",
					  "extendedTimeOut": "1000",
					  "showEasing": "swing",
					  "hideEasing": "linear",
					  "showMethod": "fadeIn",
					  "hideMethod": "fadeOut"
					}
					fetchUsers();
				}else{
					toastr["error"](response["message"])

					toastr.options = {
					  "closeButton": true,
					  "debug": false,
					  "newestOnTop": false,
					  "progressBar": true,
					  "positionClass": "toast-top-right",
					  "preventDuplicates": false,
					  "onclick": null,
					  "showDuration": "300",
					  "hideDuration": "1000",
					  "timeOut": "5000",
					  "extendedTimeOut": "1000",
					  "showEasing": "swing",
					  "hideEasing": "linear",
					  "showMethod": "fadeIn",
					  "hideMethod": "fadeOut"
					}
				}

				$("#form")[0].reset();
			}
		});

	});




	function fetchUsers(){
		$.ajax({
			url: "<?php echo base_url()?>AjaxController/fetchUsers",
			type: "post",
			dataType: "json",
			success:function(response){
				var tbody = "";
				var i;
				for(i=0; i<response.length; i++){
					tbody += "<tr>";
					tbody += "<td>"+response[i]["id"]+"</td>";
					tbody += "<td>"+response[i]["username"]+"</td>";
					tbody += "<td>"+response[i]["password"]+"</td>";
					tbody += "</tr>";
				}
				$("#tbody").html(tbody);
			}
		});
	}

	fetchUsers();
</script>




	</div>
</body>
</html>