<?php
/**
 * 
 */
class AjaxModel extends CI_Model
{
	
	function insertData($data){
		return $this->db->insert('users',$data);
	}

	function fetchUsers(){
		return $this->db->get('users')->result();
	}
	
}
?>