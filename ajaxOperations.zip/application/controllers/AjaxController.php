<?php
class AjaxController extends CI_Controller
{
	
	function index(){
		$this->load->view('index');
	}

	function addUsers(){
		$this->form_validation->set_rules("username","Username","required");
		$this->form_validation->set_rules("password","Username","required");
		if($this->form_validation->run() == true){

			$data = array(
				'username' => $this->input->post('username'),
				'password' => $this->input->post('password')
			);



			$this->AjaxModel->insertData($data);
			$response["status"]  = "success";
			$response["message"] = "User has been created!";
		}else{
			$response["status"]  = "failed";
			$response["message"] = "Fields can't be empty";
		}

		echo json_encode($response);
	}


	function fetchUsers(){
		$response = $this->AjaxModel->fetchUsers();
		echo json_encode($response);
	}
	
}
?>